package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class Controller {
    // variable declaration
    int clicks = 0;
    @FXML private Button btnClickMe;
    @FXML private Label lblClickDisplay;
    @FXML private Button btnSettings;



    // main button press
    @FXML public void buttonPressed(javafx.event.ActionEvent actionEvent) {
        clicks++;
        lblClickDisplay.setText(clicks + " clicks");
    }
    // settings button press
    @FXML public void settingButtonPress(ActionEvent actionEvent) throws IOException {
        FXMLLoader settingLoader = new FXMLLoader(getClass().getResource("settingsUI.fxml"));
        Parent settingsScreen = settingLoader.load();
        Stage settings = (Stage)lblClickDisplay.getScene().getWindow();
        Scene settingsScene = new Scene(settingsScreen, 1280, 800);
        settings.setScene(settingsScene);
        settings.show();
    }
    // shop button press
    @FXML public void shopButtonPress(ActionEvent actionEvent) throws IOException{
        FXMLLoader shopLoader = new FXMLLoader(getClass().getResource("shopUI.fxml"));
        Parent shopScreen = shopLoader.load();
        Stage shop = (Stage)lblClickDisplay.getScene().getWindow();
        Scene shopScene = new Scene(shopScreen, 1280, 800);
        shop.setScene(shopScene);
        shop.show();
    }

    // back to main screen button press
    @FXML public void backToMainButtonPress(ActionEvent actionEvent) throws IOException{
        FXMLLoader mainLoader = new FXMLLoader(getClass().getResource("idleUI.fxml"));
        Parent mainScreen = mainLoader.load();
        Stage main = (Stage)lblClickDisplay.getScene().getWindow();
        Scene mainScene = new Scene(mainScreen, 1280, 800);
        main.setScene(mainScene);
        main.show();
    }
}
