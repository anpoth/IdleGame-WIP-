package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{

        // creation of main screen
        Parent main = FXMLLoader.load(getClass().getResource("idleUI.fxml"));
        primaryStage.setTitle("Idle Game");
        primaryStage.setScene(new Scene(main, 1280, 800));
        primaryStage.show();
    }


    public static void main(String[] args) {
        Application.launch();
    }
}
